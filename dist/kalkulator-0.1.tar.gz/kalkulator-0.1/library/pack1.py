

def dodaj_liczby(licz1, licz2):
    return licz1 + licz2

def odejmij_liczby(licz1, licz2):
    return licz1 - licz2

def pomnóż_liczby(licz1, licz2):
    return licz1 * licz2

def podziel_liczby(licz1, licz2):
    return licz1 / licz2

def potęguj_liczby(licz1, licz2):
    return licz1 ** licz2
print(pomnóż_liczby(1111111111111111,111111111111))
