from setuptools import setup

setup(
    name="kalkulator",
    version='0.1',
    description='Prosty kalkulator',
    url='',
    author='Jan Załuska',
    author_email='jzaluska@st.swps.edu.pl',
    license='unlicense',
    packages=['library'],
    zip_safe=False
)